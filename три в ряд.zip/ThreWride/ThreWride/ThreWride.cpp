﻿#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <windows.h>

using namespace std;

const int WIDTH = 8;
const int HEIGHT = 8;
const int COLORS = 6;
const int CELL_SIZE = 3; // Размер клетки в символах

class Game {
private:
    vector<vector<int>> board;
    int score;
    bool gameOver;
    HANDLE hConsole;
    COORD selectedCell;
    bool hasSelection;

    void initializeBoard() {
        board.resize(HEIGHT, vector<int>(WIDTH));
        for (int y = 0; y < HEIGHT; ++y) {
            for (int x = 0; x < WIDTH; ++x) {
                board[y][x] = rand() % COLORS + 1;
            }
        }
        // Убедимся, что нет совпадений при старте
        while (checkMatches()) {
            removeMatches();
            fillBoard();
        }
        selectedCell = { -1, -1 };
        hasSelection = false;
    }

    void drawBoard() {
        system("cls");
        cout << "Score: " << score << "\n\n";

        for (int y = 0; y < HEIGHT; ++y) {
            for (int x = 0; x < WIDTH; ++x) {
                // Рисуем клетку
                if (hasSelection && selectedCell.X == x && selectedCell.Y == y) {
                    SetConsoleTextAttribute(hConsole, 240); // Выделение выбранной клетки
                }
                else {
                    // Цвета для разных типов фигур
                    switch (board[y][x]) {
                    case 1: SetConsoleTextAttribute(hConsole, 12); break; // Красный
                    case 2: SetConsoleTextAttribute(hConsole, 10); break; // Зеленый
                    case 3: SetConsoleTextAttribute(hConsole, 9); break;  // Голубой
                    case 4: SetConsoleTextAttribute(hConsole, 14); break; // Желтый
                    case 5: SetConsoleTextAttribute(hConsole, 13); break; // Фиолетовый
                    case 6: SetConsoleTextAttribute(hConsole, 11); break; // Бирюзовый
                    }
                }

                // Рисуем фигуру (3 символа в ширину для лучшего отображения)
                cout << " " << board[y][x] << " ";

                SetConsoleTextAttribute(hConsole, 7); // Сброс цвета
            }
            cout << "\n\n";
        }
        cout << "\nУправление: клик - выбрать фигуру, ESC - выход\n";
    }

    bool isValidPosition(int x, int y) {
        return x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT;
    }

    bool checkMatches() {
        bool found = false;

        // Проверка по горизонтали
        for (int y = 0; y < HEIGHT; ++y) {
            for (int x = 0; x < WIDTH - 2; ++x) {
                if (board[y][x] != 0 &&
                    board[y][x] == board[y][x + 1] &&
                    board[y][x] == board[y][x + 2]) {
                    found = true;
                }
            }
        }

        // Проверка по вертикали
        for (int x = 0; x < WIDTH; ++x) {
            for (int y = 0; y < HEIGHT - 2; ++y) {
                if (board[y][x] != 0 &&
                    board[y][x] == board[y + 1][x] &&
                    board[y][x] == board[y + 2][x]) {
                    found = true;
                }
            }
        }

        return found;
    }

    void removeMatches() {
        vector<vector<bool>> toRemove(HEIGHT, vector<bool>(WIDTH, false));

        // Помечаем совпадения по горизонтали
        for (int y = 0; y < HEIGHT; ++y) {
            for (int x = 0; x < WIDTH - 2; ++x) {
                if (board[y][x] != 0 &&
                    board[y][x] == board[y][x + 1] &&
                    board[y][x] == board[y][x + 2]) {
                    toRemove[y][x] = true;
                    toRemove[y][x + 1] = true;
                    toRemove[y][x + 2] = true;
                }
            }
        }

        // Помечаем совпадения по вертикали
        for (int x = 0; x < WIDTH; ++x) {
            for (int y = 0; y < HEIGHT - 2; ++y) {
                if (board[y][x] != 0 &&
                    board[y][x] == board[y + 1][x] &&
                    board[y][x] == board[y + 2][x]) {
                    toRemove[y][x] = true;
                    toRemove[y + 1][x] = true;
                    toRemove[y + 2][x] = true;
                }
            }
        }

        // Удаляем помеченные и увеличиваем счет
        for (int y = 0; y < HEIGHT; ++y) {
            for (int x = 0; x < WIDTH; ++x) {
                if (toRemove[y][x]) {
                    board[y][x] = 0;
                    score += 10;
                }
            }
        }
    }

    void fillBoard() {
        // Падение фигур сверху
        for (int x = 0; x < WIDTH; ++x) {
            int emptyY = HEIGHT - 1;
            for (int y = HEIGHT - 1; y >= 0; --y) {
                if (board[y][x] != 0) {
                    board[emptyY][x] = board[y][x];
                    if (emptyY != y) board[y][x] = 0;
                    emptyY--;
                }
            }

            // Заполнение пустых мест новыми фигурами
            for (int y = emptyY; y >= 0; --y) {
                board[y][x] = rand() % COLORS + 1;
            }
        }
    }

    bool swapTiles(int x1, int y1, int x2, int y2) {
        if (!isValidPosition(x1, y1) || !isValidPosition(x2, y2)) return false;
        if (abs(x1 - x2) + abs(y1 - y2) != 1) return false; // Только соседние клетки

        swap(board[y1][x1], board[y2][x2]);

        bool hasMatch = checkMatches();
        if (!hasMatch) {
            // Если нет совпадений, возвращаем как было
            swap(board[y1][x1], board[y2][x2]);
            return false;
        }

        return true;
    }

    COORD getCellFromMousePos(int mouseX, int mouseY) {
        // Преобразуем координаты мыши в координаты клетки
        COORD cell;
        cell.X = mouseX / CELL_SIZE;
        cell.Y = (mouseY - 2) / 2; // Учитываем заголовок (score) и пустые строки

        if (cell.X >= 0 && cell.X < WIDTH && cell.Y >= 0 && cell.Y < HEIGHT) {
            return cell;
        }
        return { -1, -1 }; // Недопустимая позиция
    }

public:
    Game() : score(0), gameOver(false) {
        srand(time(0));
        hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        initializeBoard();
    }

    void run() {
        // Настройка консоли для обработки событий мыши
        HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
        SetConsoleMode(hInput, ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT);

        INPUT_RECORD inputRecord;
        DWORD events;

        while (!gameOver) {
            drawBoard();

            ReadConsoleInput(hInput, &inputRecord, 1, &events);

            if (inputRecord.EventType == MOUSE_EVENT) {
                auto mouseEvent = inputRecord.Event.MouseEvent;

                if (mouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) {
                    // Обработка клика мыши
                    COORD cell = getCellFromMousePos(mouseEvent.dwMousePosition.X, mouseEvent.dwMousePosition.Y);

                    if (cell.X != -1 && cell.Y != -1) {
                        if (!hasSelection) {
                            // Первый выбор
                            selectedCell = cell;
                            hasSelection = true;
                        }
                        else {
                            // Второй выбор - попытка обмена
                            if ((abs(selectedCell.X - cell.X) == 1 && selectedCell.Y == cell.Y) ||
                                (abs(selectedCell.Y - cell.Y) == 1 && selectedCell.X == cell.X)) {
                                if (swapTiles(selectedCell.X, selectedCell.Y, cell.X, cell.Y)) {
                                    while (checkMatches()) {
                                        drawBoard();
                                        Sleep(300);
                                        removeMatches();
                                        drawBoard();
                                        Sleep(300);
                                        fillBoard();
                                    }
                                }
                            }
                            hasSelection = false;
                        }
                    }
                }
            }
            else if (inputRecord.EventType == KEY_EVENT &&
                inputRecord.Event.KeyEvent.wVirtualKeyCode == VK_ESCAPE) {
                gameOver = true;
            }
        }
    }
};

int main() {
    // Настройка кодировки и заголовка окна
    setlocale(LC_ALL, "Rus");
    SetConsoleOutputCP(65001);
    SetConsoleTitle(L"Три в ряд - управление мышкой");

    // Увеличиваем размер консоли для отображения поля
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SMALL_RECT windowSize = { 0, 0, WIDTH * CELL_SIZE, HEIGHT * 2 + 5 };
    SetConsoleWindowInfo(hConsole, TRUE, &windowSize);

    Game game;
    game.run();
    return 0;
}